class Student
  {
    constructor(name,age,grade)
    {
      this.name = name;
      this.grade = grade;
      this.age = age;
      
    }
    
    display()
    {
      console.log(this.name);
      console.log(this.age);
      console.log(this.grade);
    }
    
  
  }

  
